import matplotlib.pyplot as plt
import pickle
import numpy as np
import os

def run_plot():
    """

    :return: Generates an image that is saved with the desired
    """
    outdir='output'
    if not os.path.exists(outdir):
        os.makedirs(outdir)

    # Plots the training losses.
    for step in ['0.5', '1e-2', '1e-5']:
        for optimizer in ['sgd','momentumsgd', 'adam', 'adagrad', 'rmsprop']:
            file_name = optimizer + '-' + step
            data = pickle.load(open(outdir+'/'+file_name+".pkl", "rb"))
            plt.plot(np.log(np.array(data['train_loss'])), label=optimizer)
        plt.ylabel('Trainig log - loss')
        plt.xlabel('Epochs')
        plt.legend()
        plt.savefig('loss '+step+' .eps')
        plt.show()


    # Plots the training accuracies.

    for step in ['0.5', '1e-2', '1e-5']:
        for optimizer in ['sgd','momentumsgd', 'adam', 'adagrad', 'rmsprop']:
            file_name = optimizer + '-' + step
            data = pickle.load(open(outdir+'/'+file_name+".pkl", "rb"))
            plt.plot(data['train_accuracy'], label=optimizer)
        plt.ylabel('Trainig accuracy')
        plt.xlabel('Epochs')
        plt.legend()
        plt.savefig('accuracy '+step+'.eps')
        plt.show()


if __name__ == "__main__":
    run_plot()
