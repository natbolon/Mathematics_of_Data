%**************************************************************************
%**************************************************************************
%*******************  EE556 - Mathematics of Data  ************************
%**************************************************************************
%**************************** LIONS@EPFL **********************************
%**************************************************************************
%**************************************************************************
function [ proj_Z ] = projNuc( Z, kappa )
%PROJNUC This function implements the projection onto nuclear norm ball.

    % Write down the projection operator here:

end

% Copyright 2015 Laboratory for Information and Inference Systems (LIONS)
%                EPFL Lausanne, 1015-Lausanne, Switzerland.
