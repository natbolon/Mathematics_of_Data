%**************************************************************************
%**************************************************************************
%*******************  EE556 - Mathematics of Data  ************************
%**************************************************************************
%**************************** LIONS@EPFL **********************************
%**************************************************************************
%**************************************************************************
function [ sharp_f ] = lmoNuc( Z, kappa )
%SHARPNUC This function implements the sharp operator for the nuclear norm
%constraint. 

    % Write down the sharp operator here:

end

% Copyright 2015 Laboratory for Information and Inference Systems (LIONS)
%                EPFL Lausanne, 1015-Lausanne, Switzerland.
